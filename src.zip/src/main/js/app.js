'use strict';

const React = require('react');

const Container = require("react-bootstrap/Container")
const Row = require("react-bootstrap/Row")
const Col = require("react-bootstrap/Col")

import { Link } from "react-router-dom";




class App extends React.Component {
    

	constructor(props) {
		super(props);
	}


	render() {
		return (

            <Container>
	            <Row>
	                <Col></Col>
	                <Col xs={12}>
	                    <div className="box box-gray">
	                        <div className="box-header">
	                             <Row>
	                                <Col>
	                                    <img src={"/favicon.ico"} />
	                                    <h3 className="box-title">Tribunal de Justiça de Goiás</h3>
	                                </Col>
	                                <Col>
	                                    <h3 className="box-title">SISTEMA DE PRÉ-CADASTRO ELETRÔNICO TJ GOIÁS – PESSOA JURÍDICA</h3>
	                                </Col>
	                            </Row>
	                        </div>
	                        <div className="box-body">
	                            <div  className="bg-gray">
	                                <p>
	                                    Este é o portal para solicitação de cadastro junto ao Tribunal de Justiça de Goiás para grandes litigantes e seus escritórios jurídicos. Inicie sua solicitação abaixo! 
	                                </p>
	                            </div>

	                            <div>
	                                <div className="info-box">
	                                    <span className="info-box-icon bg-green">
	                                        <i className="far fa-star"></i>
	                                    </span>
	                                    <div className="info-box-content">
	                                        <span className="info-box-number"><Link to="/signup">Solicitar Cadastro </Link> </span>
	                                    </div>
	                                </div>

	                                <div className="info-box">
	                                    <span className="info-box-icon bg-yellow">
	                                      <i className="far fa-flag"></i>
	                                    </span>
	                                    <div className="info-box-content">
	                                        <span className="info-box-number">Acompanhar Solicitação de Cadastro</span>
	                                    </div>
	                                </div>


	                                
	                            </div>
			                </div>
	                    </div>

	                </Col>
	                <Col>
	                </Col>
	            </Row>
	        </Container>

		)
	}
}


export default App;

