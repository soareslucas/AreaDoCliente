package br.jus.tjgo.litigantes;


import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @author 
 */
public interface EscritorioRepository extends PagingAndSortingRepository<Escritorio, Long> {

}
