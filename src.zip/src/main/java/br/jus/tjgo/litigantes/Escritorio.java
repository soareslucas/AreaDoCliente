package br.jus.tjgo.litigantes;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class Escritorio {

	private @Id @GeneratedValue Long id;
	private String CNPJ;
	private String nome;
	private String endereco;
	private String nomeResponsavel;
	private String vinculo;
	private String telefone;
	private String telefone2;
	private String email;
	private String nomeGestor;
	private String cpfGestor;

	private Escritorio() {}

	public Escritorio(String CNPJ, String nome, String endereco, String nomeResponsavel, String vinculo, String telefone, String telefone2, String email, String nomeGestor, String cpfGestor) {
		this.CNPJ = CNPJ;
		this.nome = nome;
		this.endereco = endereco;
		this.nomeResponsavel = nomeResponsavel;
		this.vinculo = vinculo;
		this.telefone = telefone;
		this.telefone2 = telefone2;
		this.email = email;
		this.nomeGestor = nomeGestor;
		this.cpfGestor = cpfGestor;
	}
}